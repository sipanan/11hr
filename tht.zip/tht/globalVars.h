#ifndef GLOBALVARS_H
#define GLOBALVARS_H

#define DE			0
#define UK			1

//INCLUDES
#include <stdio.h>
#include <string.h>
#include "USB.h"
#include "HardwareProfile.h"
#include "SD-SPI.h"
#include "FSIO.h"
#include "usb_function_msd.h"
#include "i2c.h"
#include "math.h"
#include <libpic30.h>

#include <stdarg.h>

//DEFAULTWERTE ANALYTIKTEIL
#define defaultTemp			0x2D;			//Temperatur = 45 �C
#define defaultFlow			0x96;			//Fluss = 150 ml/min
#define defaultPressure		0x1E;			//Druck = 30 mbar
#define defaultSensibility	0x05;			//Empfindlichkeit = 5
#define defaultSplittime	0x3C;			//Splitzeit = 60 Sek.

//GER�TEDATEN
extern const int SN;						//Seriennummer des Ger�ts
extern const char pwd[9];					//Passwort f�r Daten�bertragung --- 00008806
extern const char pwd_master[9];			//Masterpasswort f�r Systemeinstellungen --- 00000110
extern unsigned long int meascount;			//Z�hler der Gesamtmessungen
extern unsigned long int errorcount;		//Z�hler der St�rungen
extern unsigned int messergebnis;			//letztes messergebnis

//BETRIEBSPARAMETER
extern unsigned short eichgasmenge;			//Eichgasmenge
extern unsigned short skalierung;			//Skalierung
extern BOOL autoMeasurement;				//Automessung an?
extern BOOL uebertragungsart;				//Art der Fern�bertragung --- True = 4-20mA, False = 0-20mA
extern unsigned short empfindlichkeit;		//Empfindlichkeit

//DATEN�BERTRAGUNG USB
extern float numberOfFiles;					//Anzahl Dateien und Ordner
extern float percentPerFile;				//Anzahl Dateien pro halbem Prozent
extern unsigned char percentComplete;		//Prozent abgeschlossen
extern unsigned int filesNo;				//aktuelles File
extern unsigned short filesCopiedRefresh;	//Timer, nach Ablauf wird Anzahl bereits kopierter Dateien neu berechnet und ausgegeben
extern unsigned int filesTotal;				//Anzahl aller Files
extern unsigned int filesCopied;			//Anzahlbereits kopierter Files
extern BOOL fileCopiedRefresh;				//Refresh Anzeige Anzahl kopierte Dateien?



int mini_sprintf(char *buf, const char *fmt, ...);


//UNSORTIERT
extern char current_date[25];				//aktuelles Datum inkl Messort
extern unsigned char readDirectory[21];		//Datum der Messdatenanzeige

extern unsigned char buffer[6];
extern unsigned short messpunkte[240];
extern char messort[9];
extern unsigned int signal;
extern unsigned int baselineConstant;
extern unsigned short volatile temperatur;
extern unsigned int sekunden;
extern unsigned int displayWait;
extern unsigned short int saeule_istwert;
extern unsigned int saeule_vorgabe;
extern unsigned short empfindlichkeit_vorgabe;
extern int flaeche_nr;
extern unsigned short vordruck_istwert;
extern unsigned short int fluss_istwert;

extern BOOL startup;				//System gestartet oder resettet?
extern BOOL volatile deviceActive;	//Messung l�uft?
extern BOOL volatile deviceStarted;	//Messung gestartet?
extern BOOL startAutoMeas;			//Automessung wurde aktiviert -> erste Messung ist CalMeas
extern BOOL checkMasterPwd;			//Masterpasswort korrekt
extern BOOL checkPwd;				//Passwort korrekt?
extern BOOL drawgraph;				//Graph sichtbar?
extern BOOL checkValue;				//Polling aktivieren?
extern BOOL checkPoll;				//Polling aktiviert
extern BOOL initResults;			//File System korrekt initialisiert?
extern BOOL meas6min;				//6 Minuten Messung im Gang? (sonst 12)
extern BOOL saveData;				//Datenspeicherung erlaubt?
extern BOOL battery_low;			//Akkuleistung niedrig?
extern BOOL battery_recharged;		//Akkuleistung wiederhergestellt?
extern BOOL malfunction;
extern BOOL lockSystem;
extern BOOL copyAll;
extern BOOL syringe;
extern BOOL IsMASet;
extern BOOL measurementNotOkay;

extern unsigned short volatile system_status;	//Statusbyte des Messger�ts
extern unsigned long int calFlaeche;			//Fl�che der letzten Kalibrierung
extern unsigned long int calFlaecheMin;
extern long int integral;						//Fl�che
extern unsigned int checkFlussCount;

extern BOOL calmeas;					//Calmeas starten?
extern BOOL cal;						//Kalibrierung starten?
extern BOOL meas;						//Messung starteb?
extern unsigned int calcMinRec;			//zur Berechnung der neuen Startzeiten
extern unsigned int calcHourRec;		//zur Berechnung der neuen Startzeiten
extern unsigned int calcMinNext;		//zur Berechnung der neuen Startzeiten
extern unsigned int calcHourNext;		//zur Berechnung der neuen Startzeiten

extern char uhrzeitLetzterLauf[6];		//Uhrzeit des letzen Laufs
extern char uhrzeitNaechsteMessung[6];	//Uhrzeit der n�chsten Messung
extern char uhrzeitNaechsteKalib[6];	//Uhrzeit der n�chsten Kalibrierung
extern char uhrzeitAktuell[6];			//aktuelle Uhrzeit als String

extern unsigned char recentValue[8];		//aktueller Datenpunkt
extern unsigned char previousValue[8];		//letzter Datenpunkt

extern unsigned int taeglicheMessung;		//Z�hler f�r t�gliche Messungen
extern char measurementType;				//Art der Messung
extern int messdatum;						//Messwert
extern int messdaten[720];					//Messwerte
extern int *messdatenptr;					//Zeiger auf aktuellen Messwert
extern int *messdatenende;					//Zeiger auf letzten Messwert

extern int counter;

extern unsigned short akku;

extern unsigned int mA1;
extern unsigned int mA2;

extern unsigned int pageNo;
extern unsigned int dateiNo;
extern unsigned int recentFileNo;

extern int peakStart;
extern int peakMitte;
extern int peakEnde;
extern int peakStartC;
extern int peakMitteC;
extern int peakEndeC;

extern char pcString[4];

extern unsigned int errorCode;
extern unsigned long int kalReportNr;
extern unsigned short malfunctionCount;

//aux variable
extern int timecountaux;

void InitVariables( void );

#endif

//EOF

