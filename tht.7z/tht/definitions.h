#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define DEUTSCH
//#define ENGLISCH

#define ODOR
//#define DEODOR
//#define NO_ODOR_ERROR		//keine St�rung f�r Odorgehalt

#define ABLEITUNG_ALT
//#define ABLEITUNG_NEU

#endif

//EOF
