#ifndef PC_H
#define PC_H

void PCRequest( void );
void PCSendPeak( int start, int mitte, int ende );

#endif

//EOF
