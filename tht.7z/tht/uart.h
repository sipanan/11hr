#ifndef UART2_H
#define UART2_H

void UARTInit( int baudRate );
void UARTPutChar( char c );
char UARTGetChar( void );

#endif

/** EOF *******************************************/

